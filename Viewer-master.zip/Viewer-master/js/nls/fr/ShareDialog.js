define({
  "widgets": {
    "ShareDialog": {
      "title": "Partager",
      "heading": "Partager cette carte",
      "url": "Lien de la carte",
      "embed": "Incorporer la carte",
      "extent": "Partager la vue cartographique courante",
      "size": "Taille (largeur/hauteur):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Courrier électronique",
      "copy": "Copier une URL courte dans le Presse-papiers",
      "copied": "Copiée"
    }
  }
});