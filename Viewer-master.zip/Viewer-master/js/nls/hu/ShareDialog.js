define({
  "widgets": {
    "ShareDialog": {
      "title": "Megosztás",
      "heading": "A térkép megosztása",
      "url": "Térkép hivatkozása",
      "embed": "Térkép beágyazása",
      "extent": "Aktuális térképnézet megosztása",
      "size": "Méret (szélesség/magasság):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Rövid URL másolása a vágólapra",
      "copied": "Másolt"
    }
  }
});