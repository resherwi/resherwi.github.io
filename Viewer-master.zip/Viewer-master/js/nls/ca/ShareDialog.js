define({
  "widgets": {
    "ShareDialog": {
      "title": "Comparteix",
      "heading": "Comparteix aquest mapa",
      "url": "Enllaç del mapa",
      "embed": "Incrusta el mapa",
      "extent": "Comparteix la visualització del mapa actual",
      "size": "Mida (amplada/altura):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Correu electrònic",
      "copy": "Copia l'adreça URL curta al porta-retalls",
      "copied": "S'ha copiat"
    }
  }
});