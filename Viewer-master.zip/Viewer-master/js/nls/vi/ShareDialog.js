define({
  "widgets": {
    "ShareDialog": {
      "title": "Chia sẻ",
      "heading": "Chia sẻ bản đồ này",
      "url": "Liên kết Bản đồ",
      "embed": "Nhúng Bản đồ",
      "extent": "Chia sẻ chế độ xem bản đồ hiện tại",
      "size": "Kích thước (chiều rộng/chiều cao):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Email",
      "copy": "Sao chép url ngắn sang bộ nhớ tạm",
      "copied": "Đã sao chép"
    }
  }
});