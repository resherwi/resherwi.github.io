define({
  "widgets": {
    "ShareDialog": {
      "title": "Jaga",
      "heading": "Jaga seda kaarti",
      "url": "Kaardi link",
      "embed": "Lisa kaart",
      "extent": "Jaga praegust kaardivaadet",
      "size": "Suurus (laius/kõrgus):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Kopeeri lühike URL lõikelauale",
      "copied": "Kopeeritud"
    }
  }
});