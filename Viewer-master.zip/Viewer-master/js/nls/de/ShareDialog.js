define({
  "widgets": {
    "ShareDialog": {
      "title": "Freigeben",
      "heading": "Diese Karte freigeben",
      "url": "Karten-Link",
      "embed": "Karte einbetten",
      "extent": "Aktuelle Kartenansicht freigeben",
      "size": "Größe (Breite/Höhe):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-Mail",
      "copy": "Kurz-URL in die Zwischenablage kopieren",
      "copied": "Kopiert"
    }
  }
});