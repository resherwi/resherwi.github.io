define({
  "widgets": {
    "ShareDialog": {
      "title": "分享",
      "heading": "共用此地圖",
      "url": "地圖連結",
      "embed": "嵌入地圖",
      "extent": "分享目前地圖範圍",
      "size": "大小(寬度/高度):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "電子郵件",
      "copy": "將簡短的 url 複製到剪貼簿",
      "copied": "已複製"
    }
  }
});