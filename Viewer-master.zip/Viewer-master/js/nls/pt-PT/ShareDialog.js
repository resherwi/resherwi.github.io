define({
  "widgets": {
    "ShareDialog": {
      "title": "Partilhar",
      "heading": "Partilhar este mapa",
      "url": "Ligação do Mapa",
      "embed": "Incorporar Mapa",
      "extent": "Partilhar atual vista de mapa",
      "size": "Tamanho (largura/altura):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Correio Eletrónico",
      "copy": "Copiar url curto para a área de transferência",
      "copied": "Copiado"
    }
  }
});