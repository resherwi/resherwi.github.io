define({
  "widgets": {
    "ShareDialog": {
      "title": "共有",
      "heading": "このマップを共有",
      "url": "マップ リンク",
      "embed": "マップの埋め込み",
      "extent": "現在のマップ ビューを共有",
      "size": "サイズ (幅/高さ):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google+",
      "emailTooltip": "電子メール",
      "copy": "短縮 URL をクリップボードにコピー",
      "copied": "コピーしました"
    }
  }
});