define({
  "widgets": {
    "ShareDialog": {
      "title": "Κοινοποίηση",
      "heading": "Κοινοποίηση αυτού του χάρτη",
      "url": "Σύνδεσμος χάρτη",
      "embed": "Ενσωμάτωση χάρτη",
      "extent": "Κοινοποίηση τρέχουσας προβολής χάρτη",
      "size": "Μέγεθος (πλάτος/ύψος):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Email",
      "copy": "Αντιγραφή σύντομου url στο πρόχειρο",
      "copied": "Αντιγράφηκε"
    }
  }
});