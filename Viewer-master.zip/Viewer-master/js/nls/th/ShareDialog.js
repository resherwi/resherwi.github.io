define({
  "widgets": {
    "ShareDialog": {
      "title": "แบ่งปัน",
      "heading": "แชร์แผนที่นี้",
      "url": "เชื่อมโยงแผนที่",
      "embed": "ผูกติดกับแผนที่",
      "extent": "แชร์แมพวิวปัจจุบัน",
      "size": "ขนาด (กว้าง/สูง):",
      "facebookTooltip": "เฟซบุ๊ค",
      "twitterTooltip": "ทวิตเตอร์",
      "gplusTooltip": "กูเกิ้ลพลัส",
      "emailTooltip": "อีเมล์",
      "copy": "คัดลอก URL ย่อไปที่คลิปบอร์ด",
      "copied": "คัดลอก"
    }
  }
});