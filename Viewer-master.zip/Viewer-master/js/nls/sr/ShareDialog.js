define({
  "widgets": {
    "ShareDialog": {
      "title": "Podeli",
      "heading": "Podeli ovu mapu",
      "url": "Link ka mapi",
      "embed": "Ugradi mapu",
      "extent": "Podeli trenutni prikaz mape",
      "size": "Veličina (širina/visina):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-Pošta",
      "copy": "Kopiraj skraćenu URL adresu u ostavu",
      "copied": "Kopirano"
    }
  }
});