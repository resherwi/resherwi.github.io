define({
  "widgets": {
    "ShareDialog": {
      "title": "공유",
      "heading": "이 맵 공유",
      "url": "맵 링크",
      "embed": "맵 임베드",
      "extent": "현재 맵 뷰 공유",
      "size": "크기(너비/높이):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "이메일",
      "copy": "간단한 URL을 클립보드에 복사",
      "copied": "복사됨"
    }
  }
});