define({
  "widgets": {
    "ShareDialog": {
      "title": "Koplietot",
      "heading": "Koplietot šo karti",
      "url": "Kartes saite",
      "embed": "Iedarināt karti",
      "extent": "Koplietot pašreizējo kartes skatu",
      "size": "Izmērs (platums/augstums):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-pasts",
      "copy": "Kopēt īso url starpliktuvē",
      "copied": "Nokopēts"
    }
  }
});