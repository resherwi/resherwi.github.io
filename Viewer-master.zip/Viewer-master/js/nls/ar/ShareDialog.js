define({
  "widgets": {
    "ShareDialog": {
      "title": "مشاركة",
      "heading": "مشاركة هذه الخريطة",
      "url": "رابط الخريطة",
      "embed": "تضمين الخريطة",
      "extent": "مشاركة عرض الخريطة الحالي",
      "size": "الحجم (الاتساع/الارتفاع):",
      "facebookTooltip": "فيس بوك",
      "twitterTooltip": "تويتر",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "البريد الإلكتروني",
      "copy": "نسخ عنوان url قصير إلى الحافظة",
      "copied": "تم النسخ"
    }
  }
});