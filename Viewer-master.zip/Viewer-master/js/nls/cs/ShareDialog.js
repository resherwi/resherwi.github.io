define({
  "widgets": {
    "ShareDialog": {
      "title": "Sdílet",
      "heading": "Sdílejte tuto mapu",
      "url": "Odkaz na mapu",
      "embed": "Vložit mapu",
      "extent": "Sdílet aktuální zobrazení mapy",
      "size": "Velikost (šířka/výška):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Zkopírovat krátkou URL do schránky",
      "copied": "Zkopírováno"
    }
  }
});