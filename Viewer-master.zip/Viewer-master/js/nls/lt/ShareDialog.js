define({
  "widgets": {
    "ShareDialog": {
      "title": "Bendrinti",
      "heading": "Bendrinti šį žemėlapį",
      "url": "Žemėlapio nuoroda",
      "embed": "Įterpti žemėlapį",
      "extent": "Bendrinti esamo žemėlapio vaizdą",
      "size": "Dydis (plotis / aukštis):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "El. paštas",
      "copy": "Nukopijuoti URL į mainų sritį",
      "copied": "Nukopijuota"
    }
  }
});