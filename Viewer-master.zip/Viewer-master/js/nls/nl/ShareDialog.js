define({
  "widgets": {
    "ShareDialog": {
      "title": "Delen",
      "heading": "Deze kaart delen",
      "url": "Kaartkoppeling",
      "embed": "Kaart inbedden",
      "extent": "Huidige kaartweergave delen",
      "size": "Grootte (breedte/hoogte):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Korte URL naar klembord kopiëren",
      "copied": "Gekopieerd"
    }
  }
});