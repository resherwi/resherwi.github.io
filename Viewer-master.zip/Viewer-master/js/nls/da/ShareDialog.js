define({
  "widgets": {
    "ShareDialog": {
      "title": "Opdatér",
      "heading": "Del dette kort",
      "url": "Kort-link",
      "embed": "Integrér kort",
      "extent": "Del den aktuelle kortvisning",
      "size": "Størrelse (bredde/højde):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Kopiér kort url til Udklipsholder",
      "copied": "Kopieret"
    }
  }
});