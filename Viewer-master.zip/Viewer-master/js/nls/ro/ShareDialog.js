define({
  "widgets": {
    "ShareDialog": {
      "title": "Partajare",
      "heading": "Partajare această hartă",
      "url": "Link către hartă",
      "embed": "Încorporare hartă",
      "extent": "Partajare vizualizare curentă de hartă",
      "size": "Dimensiune (lăţime/înălţime):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail",
      "copy": "Copiere URL scurt în clipboard",
      "copied": "Copiat"
    }
  }
});